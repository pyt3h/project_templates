const initialState = {
  counter: 0
}

const reducer = (state=initialState, action) => {
  // TODO: Add extra actions' processing
  return state;
}

export default reducer;